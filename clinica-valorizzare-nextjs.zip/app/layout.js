export const metadata = { title: "Clínica Valorizzare" };
export default function RootLayout({children}) {
 return <html lang="pt-br"><body style={{margin:0,fontFamily:"Arial, sans-serif"}}>{children}</body></html>
}