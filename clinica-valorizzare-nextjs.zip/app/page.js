export default function Page(){
 return (
  <main>
   <header style={{padding:20,display:"flex",justifyContent:"space-between",alignItems:"center",background:"#fff",borderBottom:"1px solid #eee"}}>
    <h1 style={{color:"#556b2f"}}>Clínica Valorizzare</h1>
    <a href="https://wa.me/5531986673185" style={{background:"#556b2f",color:"#fff",padding:"10px 16px",borderRadius:10,textDecoration:"none"}}>Agendar</a>
   </header>
   <section style={{padding:40}}>
    <h2>Beleza, cuidado e bem-estar</h2>
    <p>Atendimento moderno em Belo Horizonte.</p>
    <p>Avenida João Rolla Filho - 899 - Belo Horizonte, Minas Gerais</p>
   </section>
  </main>
 )
}